package com.edu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DeleteRecord {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		String driver ="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/batch10888db";
		String un = "root";
		String pass="root";
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		
		Scanner sc = new Scanner(System.in);
		
		//load Driver
		Class.forName(driver);
		
		//make the connection
		conn = DriverManager.getConnection(url, un, pass);
		
		//create statement
		stmt = conn.createStatement();
		
		System.out.println("Enter the id to be deleted :");
		int id = sc.nextInt();
		
		String sel ="select * from emp where eid = "+id;
		rs = stmt.executeQuery(sel);
		if(rs.next()) {
			
		
		String sql="delete from emp where eid = "+id;
		int i = stmt.executeUpdate(sql);
		
		if(i>0) {
			System.out.println("Record deleted");
		}
		}
		else {
			System.out.println("Employee ID "+id+"Not Exists");
		}

	}

}
