package com.edu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class PreparedStatementInsertRecord {

    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        String driver = "com.mysql.cj.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/batch10888db";
        String un = "root";
        String pass = "root";

        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        // Load the driver
        Class.forName(driver);

        // Make the connection
        conn = DriverManager.getConnection(url, un, pass);

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter id, name, email, fees, age");
        int id = sc.nextInt();

        String name = sc.next();
        String email = sc.next();
        float fees = sc.nextFloat();
        int age = sc.nextInt();

        String sql = "insert into student values(?,?,?,?,?)";

        pst = conn.prepareStatement(sql);
        pst.setInt(1, id);
        pst.setString(2, name);
        pst.setString(3, email);
        pst.setFloat(4, fees);
        pst.setInt(5, age);

        // Execute the update
        int i = pst.executeUpdate();
        if (i > 0) {
            System.out.println("Record is inserted");
        } else {
            System.out.println("Record is not inserted");
        }

        // Close resources
        pst.close();
        conn.close();
    }
}
