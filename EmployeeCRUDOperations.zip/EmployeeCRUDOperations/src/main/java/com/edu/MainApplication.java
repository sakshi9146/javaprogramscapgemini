package com.edu;

import java.sql.SQLException;
import java.util.Scanner;

public class MainApplication {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner sc = new Scanner(System.in);
		for(;;) {
			
		
		System.out.println("Employe Menu");
		System.out.println("1.Display Employees");
		System.out.println("2.Add Employee");
		System.out.println("3.Update Employee");
		System.out.println("4.Delete Employee");
		
		System.out.println("Enter UR choice");
		
		int choice = sc.nextInt();
		switch(choice) {
		
		case 1:EmployeeOperations.displayEmployees();
			break;
		
		case 2:EmployeeOperations.addEmployees();
			break; 
			
		case 3:EmployeeOperations.updateEmployees();
			break;	
			
		case 4:EmployeeOperations.deleteEmployees();
		    break;
		 
		default:System.out.println("Invalid INput");    
		}//switch
		System.out.println("Do U want to continu y, any other key to exist");
		char ch = sc.next().toLowerCase().charAt(0);
		
		if(ch!='y') {
			break;
		}
		
	}
		System.out.println("Program terminated ");

	}

}
