package com.edu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class UpdateStudentSwitchCase {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/batch10888db";
		String un="root";
		String pass="root";
		
		int i;
		
		Connection conn=null;
		Statement stmt = null;
		ResultSet rs = null;
		Scanner sc = new Scanner(System.in);
		//load the driver
		Class.forName(driver);
				
		//make the connection
		conn = DriverManager.getConnection(url,un,pass);
		stmt = conn.createStatement();
		
		for(;;) {
		System.out.println("Enter student id");
		int id=sc.nextInt();
		
		String sql = "select * from student where sid = "+id;
		rs= stmt.executeQuery(sql);
		
		if(rs.next()) {
			
		
	 
		System.out.println("MENU FOR UPDATE");
		System.out.println("1.To update name");
		System.out.println("2.To update Fees");
		System.out.println("3.To update email");
		System.out.println("4.To update age");
		System.out.println("Enter your choice ");
		
		int ch = sc.nextInt();
		switch(ch) {
		//update name
		case 1: System.out.println("Enter name to update  ");
				String n =sc.next();
				sql ="update student set sname ='"+n+"'where sid = "+id;
				i = stmt.executeUpdate(sql);
				if(i>0) {
					System.out.println("name is changed ");
				}else {
					System.out.println("error occured");
				}
				break;
				
		//update fees 
		case 2:System.out.println("enter the fees to update");
			int n1=sc.nextInt();
			sql=" update student set sfees = "+n1+ " where sid = "+ id;
			i =stmt.executeUpdate(sql);
			if(i>0) {
				System.out.println("fees is updated ");
			}else {
				System.out.println("Error");
			}
		    break;
		//update email 
		case 3:System.out.println("Enter Email to update :");
				String n2=sc.next();
				sql=" update student set semail = "+n2+ "where sid = "+ id;
				i=stmt.executeUpdate(sql);
				if(i>0) {
					System.out.println("Email is updated ");
				}else {
					System.out.println("Error Occured ");
				}
				break;
		  			//System.exit(0);
		//update age 
		case 4:System.out.println("Enter Age to update : ");	
				int n3 =sc.nextInt();
				sql=" update student set age = "+n3+ "where sid = "+id;
				i=stmt.executeUpdate(sql);
				if(i>0) {
					System.out.println("Age updated ");
				}else {
					System.out.println("Error occured ");
				}
				break;
		
			default:
				System.out.println("Invalid choice :(");
		}//switch
		
		}//if(rs.next())
		else {
			System.out.println("Record not Exits");
		}
		
		System.out.println("Do you want to continue  y to continue any other key to stop");
		char choice = sc.next().toLowerCase().charAt(0);
		if(choice!='y') {
			System.out.println("Program is  terminated ");
			break;
		}
		}//for(;;)
	}//main

}//class
