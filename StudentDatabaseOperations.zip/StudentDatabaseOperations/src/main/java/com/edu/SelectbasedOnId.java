package com.edu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class SelectbasedOnId {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/batch10888db";
		String un="root";
		String pass="root";
		
		
		Connection conn=null;
		Statement stmt = null;
		ResultSet rs = null;
		
		//load the driver
				Class.forName(driver);
				
		//make the connection
		conn = DriverManager.getConnection(url,un,pass);
		stmt = conn.createStatement();
		
		
		//Scanner sc = new Scanner(System.in);
		
		//System.out.println("Enter id");
		//int id = sc.nextInt();
		 
		 String sql="select * from student";
		 System.out.println("Select student record");
		//String sql ="select * from student where sid="+id;
		 
		 
		rs= stmt.executeQuery(sql);
		System.out.println(rs);
		//System.out.println("Id\tName\tEmail\tfees");
		System.out.printf("%-10s %-15s %-20s %-15s" ,"StudentID","StudentName","StudentEmail","StudentFees");
		
		System.out.println();
		
		while(rs.next()) {
			 int id = rs.getInt("sid");
			 String name =rs.getString("sname");
			 String email = rs.getString("semail");
			 float fees = rs.getFloat("sfees");
			 
			 //System.out.println(id+"\t"+name+"\t"+email+"\t"+fees);
			 /*int         | NO   | PRI | NULL    |       |
| sname  | varchar(75) | YES  |     | NULL    |       |
| semail | varchar(50) | YES  |     | NULL    |       |
| sfees  | float       | NO   |     | NULL    |       |
| age    | int
*/
			 System.out.printf("%-10d %-15s %-20s %-15s",id,name,email,fees);
			 System.out.println();
		 }
		 
	}

}
