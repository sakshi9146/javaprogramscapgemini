package com.edu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.Scanner;

public class UpdateDatabase {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		String driver = "com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/batch10888db";
		String un = "root";
		String pass="root";
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		Class.forName(driver);
		
		conn = DriverManager.getConnection(url, un, pass);
		stmt = conn.createStatement();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter employee Id :");
		int id = sc.nextInt();
		
		//System.out.println("Enter the date to be updated :");
		//String d =sc.next();
		
		System.out.println("Enter the name to be updated ");
		String name = sc.next();
		
		String sel ="select * from emp where eid = "+id;
		rs=stmt.executeQuery(sel);
		if(rs.next()) {
			String sql= " UPDATE emp SET ename = '"+ name  + "' WHERE eid = " +id;
			int i = stmt.executeUpdate(sql);
			
			if(i>0) {
				System.out.println("Record updated ");
			}
		}else {
			System.out.println("Record does not exist");
		}
	}

}
