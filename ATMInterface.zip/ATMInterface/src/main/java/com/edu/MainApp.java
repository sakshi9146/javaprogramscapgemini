package com.edu;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class MainApp {

	public static void main(String[] args) {
		 try (Connection conn = DatabaseOperations.getConnection()) {
		Scanner sc = new Scanner(System.in);
		for(;;) {
			
			
			 System.out.println("------------------------------------------------------------");
		        System.out.println("|                    WELCOME TO BANK XYZ                   |");
		        System.out.println("------------------------------------------------------------");
		        System.out.println("|                                                          |");
		        System.out.println("|                    1. Withdraw Cash                      |");
		        System.out.println("|                    2. Deposit Cash                       |");
		        System.out.println("|                    3. Check Balance                      |");
		        System.out.println("|                    4. Transfer Funds                     |");
		        System.out.println("|                    5. Change PIN                         |");
		        System.out.println("|                    6. Add New Account                    |");
		        System.out.println("|                    7. Exit                               |");
		        System.out.println("|                                                          |");
		        System.out.println("------------------------------------------------------------");
		        System.out.print("\nPlease select an option: ");
		        
		        int choice = sc.nextInt();
		        switch(choice) {
		        
		        case 1:
                    BankingOperations.withdrawCash(conn);
                    break;
                case 2:
                    BankingOperations.depositCash(conn);
                    break;
                case 3:
                    BankingOperations.checkBalance(conn);
                    break;
                case 4:
                    BankingOperations.transferFunds(conn);
                    break;
                case 5:
                    BankingOperations.changePin(conn);
                    break;
                
                case 6:
                    BankingOperations.addNewAccount(conn);
                    break;
                case 7:
                    System.out.println("Exiting ATM. Thank you for using our services!");
                    
                    break;
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
		        }
		        System.out.println("Do U want to continu y, any other key to exist");
				char ch = sc.next().toLowerCase().charAt(0);
				
				if(ch!='y') {
					break;
				}
		}
		System.out.println("Program terminated ");

	}catch (ClassNotFoundException | SQLException e) {
        e.printStackTrace();

}
}
}
