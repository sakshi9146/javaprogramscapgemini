package com.edu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class AddEmployee {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		String driver ="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/batch10888db";
		String un = "root";
		String pass="root";
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		
		Scanner sc = new Scanner(System.in);
		
		//load Driver
		Class.forName(driver);
		
		//make the connection
		conn = DriverManager.getConnection(url, un, pass);
		
		//create statement
		stmt = conn.createStatement();
		
		int eid;
		String ename;
		String d;
		
		System.out.println("Enter id , Name, DOB");
		eid = sc.nextInt();
		ename = sc.next();
		d=sc.next();
		
		//before insert record check id exits
		
		String sel="select * from emp where eid = "+eid;
		rs = stmt.executeQuery(sel);
		if(rs.next()) {
			
		System.out.println("eid = "+eid+" exits in database");
		}else {
			
		
		String sql="insert into emp values("+eid+",'"+ename+"','"+d+"')";
		int i=stmt.executeUpdate(sql);
		if(i>0) {
			System.out.println("Record inserted Successfully");
		}else {
			System.out.println("Error!!!");
		}
		}
}
}