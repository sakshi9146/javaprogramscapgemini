package com.edu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class UpdateRecordUsingSwitchCase {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		String driver ="com.mysql.cj.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/batch10888db";
		String un="root";
		String pass="root";
		
		Connection conn = null;
		Statement stmt =null;
		ResultSet rs = null;
		
		Scanner sc = new Scanner(System.in);
		int i;
		
		Class.forName(driver);
		
		conn = DriverManager.getConnection(url, un, pass);
		stmt = conn.createStatement();
		
		for(;;) {
			System.out.println("Enter Id: ");
			int id = sc.nextInt();
			
			String sql="select * from employee where eid = "+id;
			rs = stmt.executeQuery(sql);
			if(rs.next()) {
				
				System.out.println("MENU FOR UPDATE ");
				System.out.println("1.To Update Name ");
				System.out.println("2.To Update age");
				System.out.println("3.To Update Email");
				System.out.println("4.To Update Salaray");
				System.out.println("Enter UR Choice :");
				
				int ch =sc.nextInt();
				switch (ch) {
				
				case 1:System.out.println("ENTER THE NAME TO UPDATE :");
						String n = sc.next();
						sql=" update employee set ename ='"+n+ "' where eid = "+id;
						i=stmt.executeUpdate(sql);
						if(i>0) {
							System.out.println("Name updated");
						}else {
							System.out.println("Error Occured");
						}
						break;
						
				case 2:System.out.println("ENTER THE AGE TO UPDATE : ");		
						int n1=sc.nextInt();
						sql=" update employee set eage = "+n1+ " where eid = "+id;
						i=stmt.executeUpdate(sql);
						if(i>0) {
							System.out.println("Age Updated ");
						}else {
							System.out.println("Error Occured");
						}
						break;
						
				case 3:System.out.println("ENTER THE EMAIL TO UPDATE : ");		
						String n2= sc.next();
						sql=" update employee set email = '"+n2+ "' where eid = "+id;
						i=stmt.executeUpdate(sql);
						if(i>0) {
							System.out.println("Email updated ");
						}else {
							System.out.println("Error occurred");
						}
						break;
						
				case 4:System.out.println("ENTER SALARY TO UPDATE : ");
						float n3=sc.nextFloat();
						sql=" update employee set esalary = "+n3+ " where eid = "+id;
						i=stmt.executeUpdate(sql);
						if(i>0) {
							System.out.println("Salary Updated ");
						}else {
							System.out.println("Error Occurred ");
						}
						break;
				default:
					System.out.println("Invalid choice :(");
				}
				
			}else {
				System.out.println("Record not exists ");
				
			}
			System.out.println("Do you want continue y to continus, any othe key to stop");
			char choice = sc.next().toLowerCase().charAt(0);
			if(choice !='y') {
				System.out.println("Program is terminated ");
				break;
			}
			
		}
	}

}
