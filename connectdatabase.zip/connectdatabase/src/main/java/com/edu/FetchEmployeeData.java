package com.edu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

public class FetchEmployeeData {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		String driver ="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/batch10888db";
		String un = "root";
		String pass="root";
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		
		//load Driver
		Class.forName(driver);
		
		//make the connection
		conn = DriverManager.getConnection(url, un, pass);
		
		//create statement
		stmt = conn.createStatement();
		
		//Execute query
		
		String sql = "select * from emp";
		
		rs = stmt.executeQuery(sql);
		
		//System.out.println("EmployeID\tEmployeeName\tEmployeeDOB");
		System.out.printf("%-12s %-15s %-15s","EmployeeId","EmployeeName","EmployeeDOB");
		System.out.println();
		while(rs.next()) {
			int eid = rs.getInt("eid");
			
			String ename = rs.getString("ename");
			
			Date d = rs.getDate("edob");
			
			//System.out.println(eid+"\t\t"+ename+"\t\t"+d);
			System.out.printf("%-12d %-15s %-15s",eid,ename,d);
			System.out.println();
			
		}
		
		
		
		
	}

}
