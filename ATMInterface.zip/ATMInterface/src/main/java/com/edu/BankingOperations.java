package com.edu;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class BankingOperations {

	private static Connection conn;

   
	private static Statement stmt;
	private static ResultSet rs;
	
	public static void withdrawCash(Connection conn) throws SQLException {
		 Scanner scanner = new Scanner(System.in);
	        System.out.println("Withdraw Cash");
	        
	        // Assuming the user provides account number and withdrawal amount
	        System.out.print("Enter account number: ");
	        int accountNumber = scanner.nextInt();
	        System.out.print("Enter amount to withdraw: ");
	        float amount = scanner.nextFloat();

	        // Your SQL query to update balance after withdrawal
	        String sql = "UPDATE accounts SET balance = balance - ? WHERE account_number = ?";
	        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
	            pstmt.setFloat(1, amount);
	            pstmt.setInt(2, accountNumber);

	            int rowsUpdated = pstmt.executeUpdate();
	            if (rowsUpdated > 0) {
	                System.out.println("Withdrawal successful.");
	            } else {
	                System.out.println("Withdrawal failed.");
	            }
	        }
	    }

		
	
	public static void depositCash(Connection conn) throws SQLException{
		
		
		  Scanner scanner = new Scanner(System.in);
	        System.out.println("Deposit Cash");

	        System.out.print("Enter account number: ");
	        int accountNumber = scanner.nextInt();
	        System.out.print("Enter amount to deposit: ");
	        float amount = scanner.nextFloat();

	        String sql = "UPDATE accounts SET balance = balance + ? WHERE account_number = ?";
	        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
	            pstmt.setFloat(1, amount);
	            pstmt.setInt(2, accountNumber);

	            int rowsUpdated = pstmt.executeUpdate();
	            if (rowsUpdated > 0) {
	                System.out.println("Deposit successful.");
	            } else {
	                System.out.println("Deposit failed.");
	            }
	}
}
	public static void checkBalance(Connection conn) throws SQLException{
		Scanner scanner = new Scanner(System.in);
        System.out.println("Check Balance");

        System.out.print("Enter account number: ");
        int accountNumber = scanner.nextInt();

        String sql = "SELECT balance FROM accounts WHERE account_number = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, accountNumber);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                float balance = rs.getFloat("balance");
                System.out.println("Current Balance: $" + balance);
            } else {
                System.out.println("Account not found.");
            }
        }
		
	}
	public static void transferFunds(Connection conn) throws SQLException{


		Scanner scanner = new Scanner(System.in);
        System.out.println("Transfer Funds");

        System.out.print("Enter source account number: ");
        int sourceAccount = scanner.nextInt();
        System.out.print("Enter destination account number: ");
        int destinationAccount = scanner.nextInt();
        System.out.print("Enter amount to transfer: ");
        float amount = scanner.nextFloat();

        // Check if the source account has sufficient balance
        float sourceBalance = getBalance(conn, sourceAccount);
        if (sourceBalance < amount) {
            System.out.println("Insufficient balance. Transfer failed.");
            return;
        }

        // Update source and destination accounts
        String sql = "UPDATE accounts SET balance = balance - ? WHERE account_number = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            // Update source account
            pstmt.setFloat(1, amount);
            pstmt.setInt(2, sourceAccount);
            pstmt.executeUpdate();

            // Update destination account
            pstmt.setFloat(1, -amount); // Negative amount to deduct from destination
            pstmt.setInt(2, destinationAccount);
            pstmt.executeUpdate();

            System.out.println("Transfer successful.");
        }
    }
		

	public static void changePin(Connection conn)throws SQLException {
		  Scanner scanner = new Scanner(System.in);
	        System.out.println("Change PIN");

	        System.out.print("Enter account number: ");
	        int accountNumber = scanner.nextInt();
	        System.out.print("Enter new PIN: ");
	        int newPin = scanner.nextInt();

	        String sql = "UPDATE accounts SET pin = ? WHERE account_number = ?";
	        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
	            pstmt.setInt(1, newPin);
	            pstmt.setInt(2, accountNumber);

	            int rowsUpdated = pstmt.executeUpdate();
	            if (rowsUpdated > 0) {
	                System.out.println("PIN changed successfully.");
	            } else {
	                System.out.println("Failed to change PIN.");
	            }
	        }
		
	}
	
	 private static float getBalance(Connection conn, int accountNumber) throws SQLException {
	        String sql = "SELECT balance FROM accounts WHERE account_number = ?";
	        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
	            pstmt.setInt(1, accountNumber);
	            ResultSet rs = pstmt.executeQuery();
	            if (rs.next()) {
	                return rs.getFloat("balance");
	            } else {
	                throw new SQLException("Account not found.");
	            }
	        }
	  }
	 
	public static void addNewAccount(Connection conn) throws SQLException {
		Scanner scanner = new Scanner(System.in);
        System.out.println("Insert Account");

        System.out.print("Enter account number: ");
        int accountNumber = scanner.nextInt();
        System.out.print("Enter account holder name: ");
        String accountHolderName = scanner.next();
        System.out.print("Enter balance: ");
        float balance = scanner.nextFloat();
        System.out.print("Enter email: ");
        String email = scanner.next();

        String sql = "INSERT INTO accounts (account_number, account_holder_name, balance, email) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, accountNumber);
            pstmt.setString(2, accountHolderName);
            pstmt.setFloat(3, balance);
            pstmt.setString(4, email);

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Account inserted successfully.");
            } else {
                System.out.println("Failed to insert account.");
            }
        }
    }
		
}
	
	

