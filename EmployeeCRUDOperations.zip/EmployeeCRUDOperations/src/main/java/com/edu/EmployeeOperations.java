package com.edu;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.Scanner;

public class EmployeeOperations {

	
	private static Connection conn;
	private static Statement stmt;
	private static ResultSet rs;
	
	public static void displayEmployees() throws ClassNotFoundException, SQLException {
		System.out.println("Display employee");
		conn = DatabaseOperations.getConnection();
        
		stmt = conn.createStatement();
		
		//Execute query
		
		String sql = "select * from employee";
		
		rs = stmt.executeQuery(sql);
		
		//System.out.println("EmployeID\tEmployeeName\tEmployeeDOB");
		System.out.printf("%-12s %-15s %-15s %-25s %-15s","EmployeeId","EmployeeName","EmployeeAge","EmployeeEmail","EmployeeSalary");
		System.out.println();
		while(rs.next()) {
			int eid = rs.getInt("eid");
			
			String ename = rs.getString("ename");
			
			int age = rs.getInt("eage");
			
			String email=rs.getString("email");
			
			float salary = rs.getFloat("esalary");
			
			//System.out.println(eid+"\t\t"+ename+"\t\t"+d);
			System.out.printf("%-12d %-15s %-15d %-25s %-15f",eid,ename,age,email,salary);
			System.out.println();
		
	}
	}
	public static void addEmployees() throws ClassNotFoundException, SQLException {
		System.out.println("Add Employess");
		conn = DatabaseOperations.getConnection();
		
          stmt = conn.createStatement();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter  id , name ,age , email, salary");
		int id = sc.nextInt();
		String name = sc.next();
		int age = sc.nextInt();
		String email = sc.next();
		float salary = sc.nextFloat();
		
		String sql = "insert into employee values('" +id+ "', '" +name+ "', '" +age+ "', '" +email+ "', '" +salary+ "')";
		
		int i = stmt.executeUpdate(sql);
		if(i>0) {
			System.out.println("Record is inserted ");
		}else {
			System.out.println("Record is not inserted");
		}
	}

	public static void updateEmployees() throws ClassNotFoundException, SQLException {
		System.out.println("Update employee ");
		conn = DatabaseOperations.getConnection();
		
		stmt = conn.createStatement();
		
		Scanner sc =  new Scanner(System.in);
		
		System.out.println("Enter id");
		int id = sc.nextInt();
		
		System.out.println("Enter the Updated Salary");
		float salary = sc.nextFloat();
		
		String sqlsel="select * from employee where eid = "+id;
		rs= stmt.executeQuery(sqlsel);
		
		if(rs.next()) {
			
		String sql ="UPDATE employee SET esalary = " + salary + " WHERE eid = "+id;
		
		int i = stmt.executeUpdate(sql);
		if(i>0) {
			System.out.println("Record is updated");
		}else {
			System.out.println("Not Updated");
		}
		
		}else {
			System.out.println("Employee ID not exits");
		}
	}

	public static void deleteEmployees() throws ClassNotFoundException, SQLException {
		System.out.println("Delete Employee");
		conn = DatabaseOperations.getConnection();
		
		stmt = conn.createStatement();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter  id ");
		int id = sc.nextInt();
		
		String sqlsel="select * from employee where eid = "+id;
		 rs = stmt.executeQuery(sqlsel);
		 
		 if(rs.next()) {
			 String sql="delete from employee where eid = "+id;
			 int i=stmt.executeUpdate(sql);
			 
			 if(i>0) {
				 System.out.println("Record deleted ");
			 }else {
				 System.out.println("Not Deleted");
			 }
		 }else {
			 System.out.println("Employee ID not Exits");
		 }
		
	}

}
