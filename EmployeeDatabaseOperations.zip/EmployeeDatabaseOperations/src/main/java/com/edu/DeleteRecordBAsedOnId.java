package com.edu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DeleteRecordBAsedOnId {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		String driver ="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/batch10888db";
		String un = "root";
		String pass="root";
		
		Connection conn = null;
		Statement stmt=null;
		ResultSet rs = null;
		
		//load driver
		Class.forName(driver);
		
		//make connection
		conn = DriverManager.getConnection(url, un, pass);
		stmt = conn.createStatement();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter  id ");
		int id = sc.nextInt();
		
		String sqlsel="select * from employee where eid = "+id;
		 rs = stmt.executeQuery(sqlsel);
		 
		 if(rs.next()) {
			 String sql="delete from employee where eid = "+id;
			 int i=stmt.executeUpdate(sql);
			 
			 if(i>0) {
				 System.out.println("Record deleted ");
			 }else {
				 System.out.println("Not Deleted");
			 }
		 }else {
			 System.out.println("Employee ID not Exits");
		 }
	}

}
