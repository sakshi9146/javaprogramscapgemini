package com.edu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnectFecthData {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/batch10888db";
		String un="root";
		String pass="root";
		
		
		Connection conn=null;
		Statement stmt = null;
		ResultSet rs = null;
		
		//load the driver
		Class.forName(driver);
		
		//make the connection
		conn = DriverManager.getConnection(url,un,pass);
		stmt = conn.createStatement();
		
		String sql ="select * from student";
		rs= stmt.executeQuery(sql);
		System.out.println("Name\tFees\tEmail");
		System.out.println("-----------------------------");
		
		while(rs.next()) {
			//String name = rs.getString("sname");//varcahr in mysql ,getString
			String name = rs.getString(2);
			//int age =rs.getInt("sage");		//int getInt
			float fees = rs.getFloat("sfees");
			//float fees = rs.getFloat(3);
			String email = rs.getString("semail");
			
			
			System.out.println(name+"\t"+fees+"\t"+email);
		}
	}

}
